var express = require('express');
var router = express.Router();
var path = require('path');
var scriptName = path.basename(__filename);
var log4js = require('log4js');
var logger = log4js.getLogger(scriptName);
var fs = require('fs');
var http = require('http');
var jsondata = require('./data.json');
var http = require('http');
var https = require('https');

function cloneObj(obj) {
  return JSON.parse(JSON.stringify(obj));
}

router.get('/config', function(req, res, next) {
  res.send(globalconfig);
});

router.put('/config', function(req, res, next) {
  var data = req.body;
  if (!data.gw_endpoint) {
    res.send('invalid data');
  }
  globalconfig.gw_endpoint = data.gw_endpoint;
  globalconfig.chaincode_ver = data.chaincode_ver;
  fs.writeFile('config.json', JSON.stringify(globalconfig, null, 2), 'utf8', function() {
    res.send('OK');
  });
});

function gwRESTCall(reqdata) {
  return new Promise((resolve, reject) => {
    var config = reqdata.config;
    var data = {
      "channel": config.channel,
      "chaincode": config.chaincode_name,
      "method": reqdata.method,
      "args": reqdata.args,
      "chaincodeVer": config.chaincode_ver
    };
    var dataStr = JSON.stringify(data);
    logger.debug(dataStr);
    var client = http;
    if(config.gw_endpoint.indexOf('https:') != -1)
    client = https;
    var endpoint = config.gw_endpoint.replace(/https?:\/\//, '');
    var parts = endpoint.split(':');
    var options = {
      hostname: parts[0],
      port: parts[1],
      path: `/restproxy1/bcsgw/rest/v1/transaction/${reqdata.action}`,
      method: 'POST',
      auth: `${config.username}:${config.password}`,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(dataStr)
      }
    };

    // options.agent = new http.Agent(options);

    const httpreq = client.request(options, (httpres) => {
      logger.debug('STATUS: ' + httpres.statusCode);
      logger.debug('HEADERS: ' + JSON.stringify(httpres.headers));
      httpres.setEncoding('utf8');
      var body = '';
      httpres.on('data', function(chunk) {
        body += chunk;
      });
      httpres.on('end', function() {
        logger.debug('BODY: ' + body)
        if(body.indexOf('401 Authorization Required') != -1) {
          reject(`ERROR: Request rejected with: 401 Authorization Required`);
          return;
        } else if(body.indexOf('Not Found -') != -1) {
          reject('ERROR: 404 ' + body);
          return;
        }
        var obj = JSON.parse(body);
        if (obj.returnCode == 'Success') {
          var ret;
          if(reqdata.action == 'query') {
            ret = obj.result;
          } else {
            ret = obj;
          }
          resolve(ret);
        } else {
          reject(obj.info);
        }
      });
    });

    httpreq.on('error', (e) => {
      console.error(e);
      reject(e.toString());
    });
    httpreq.write(dataStr);
    httpreq.end();
  });
}

router.post('/query/:key', function(req, res, next) {
  var key = req.params.key;
  var config = req.body.config;

  var channelMapping;
  if(globalconfig.channel_mapping) {
    var mappingKey = Object.keys(globalconfig.channel_mapping)[0];
    var mappings = globalconfig.channel_mapping[mappingKey];
    if(config.channel == mappingKey) {
      channelMapping = mappings;
    }
  }

  if(channelMapping) {
    logger.debug('ChannelMapping is true');
    var promises = [];
    channelMapping.forEach(val => {
      var newConfig = cloneObj(config);
      newConfig.channel = val;
      promises.push(gwRESTCall({
        action: 'query',
        method: 'getHistoryForRecord',
        args: [key],
        config: newConfig
      }));
    });

    Promise.all(promises).then(results => {
      var ret = [];
      results.forEach(val => {
        ret = ret.concat(JSON.parse(val.payload));
      });
      res.send(JSON.stringify(ret));
    }).catch(err => {
      res.status(500).send(err.toString());
    });
  } else {
    logger.debug('ChannelMapping is false');
    gwRESTCall({
      action: 'query',
      method: 'getHistoryForRecord',
      args: [key],
      config: config
    }).then(result => {
      res.send(result);
    }).catch(err => {
      res.status(500).send(err);
    });
  }
});

router.post('/asset/:owner', function(req, res, next) {
  var owner = req.params.owner;
  var config = req.body.config;
  gwRESTCall({
    action: 'query',
    method: 'queryVehiclePartByOwner',
    args: [owner],
    config: config
  }).then(result => {
    res.send(result);
  }).catch(err => {
    res.status(500).send(err);
  });
});

router.post('/invoke', function(req, res, next) {
  var data = req.body.data;
  var config = req.body.config;
  gwRESTCall({
    action: 'invocation',
    method: data.method,
    args: data.args,
    config: config
  }).then(result => {
    res.send(result);
  }).catch(err => {
    res.status(500).send(err);
  });
});

module.exports = router;
