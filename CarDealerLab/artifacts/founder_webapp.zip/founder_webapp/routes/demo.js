var express = require('express');
var router = express.Router();
var path = require('path');
var scriptName = path.basename(__filename);
var log4js = require('log4js');
var logger = log4js.getLogger(scriptName);
var fs = require('fs');
var http = require('http');
var jsondata = require('./data.json');

function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function cloneObj(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function makeid() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (var i = 0; i < 12; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}

router.post('/query', function(req, res, next) {
  var method = req.body.method;
  var ret = [];
  var brands = [
    'mercedes',
    'ford',
    'audi',
    'toyota',
    'honda',
    'chevy',
    'mercedes',
    'ford',
    'audi',
    'toyota',
    'honda',
    'chevy'
  ];
  switch (method) {
    case 'queryRecordByKeys':
      ret = jsondata;
      break;
    case 'queryVehiclePartByOwner':
      ret = jsondata.vehiclePartsOfOwner;
      break;
    case 'getHistoryForRecord':
      var key = req.body.args[0];
      var type,
        num,
        id;
      if (key.startsWith('ser')) {
        type = 'vehicleParts';
        id = 'serialNumber';
      } else {
        type = 'vehicles';
        id = 'chassisNumber';
      }
      num = jsondata[type].length;
      var index = Math.floor(Math.random() * num);
      logger.debug(`${type}, ${num}, ${index}`);
      var dataTemplate = jsondata[type][index];
      dataTemplate[id] = key;
      // var tranDate = Number(dataTemplate['assemblyDate']);
      var tranDate = Date.now() - 3600 * 24 * 1 * 1000;

      var recordNum = Math.floor(Math.random() * 5 + 3);
      for (var i = 0; i < recordNum; i++) {
        var newOwner = brands[i];
        var dateForward = getRandomIntInclusive(5000000, 20000000);
        logger.debug(`${newOwner}, ${dateForward}`);
        if (i > 0) {
          tranDate += dateForward;
        }

        var newCarObj = cloneObj(dataTemplate);
        newCarObj['owner'] = newOwner;
        var histObj = {
          "TxId": makeid(),
          "Value": newCarObj,
          "Timestamp": new Date(tranDate).toISOString(),
          "IsDelete": false
        };
        logger.debug(histObj);
        ret.push(histObj);
      }

      logger.debug('================================');
      break;
  }
  // logger.debug(ret);
  res.send(JSON.stringify({returnCode:'Success',result:JSON.stringify(ret)}));
});

router.post('/invocation', function(req, res, next) {
  var args = req.body.args;
  var method = req.body.method;
  var item;
  if (method == 'transferVehiclePart')
    item = 'vehicle part';
  else if (method == 'transferVehicle')
    item = 'vehicle';
  res.send(JSON.stringify({returnCode:'Success', message: `Transferred ${item} ${args[0]} from ${args[1]} to ${args[2]}`}));
});

module.exports = router;
