/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
 define(['ojs/ojcore', 'knockout', 'jquery', 'promise', 'ojs/ojknockout', 'ojs/ojselectcombobox', 'ojs/ojchart', 'ojs/ojcheckboxset', 'ojs/ojdialog', 'ojs/ojradioset',
 'ojs/ojlistview', 'ojs/ojinputtext', 'ojs/ojmenu', 'ojs/ojlistview', 'ojs/ojdatetimepicker', 'ojs/ojtimezonedata',
 'ojs/ojarraytabledatasource', 'ojs/ojcollapsible', 'ojs/ojinputnumber', 'ojs/ojtabs', 'ojs/ojtable', 'ojs/ojknockout-validation',
 'ojs/ojbutton', 'ojs/ojtimeline'],
 function (oj, ko, $, Promise) {

   function MainViewModel() {
     var self = this;
     self.serNum = ko.observable();

     self.vehicleParts = ko.observableArray([]);
     self.datasourceVehicleParts = new oj.ArrayTableDataSource(self.vehicleParts, {idAttribute: "serialNumber"});
     self.columnsVehicleParts = ko.observableArray([]);

     self.vehicles = ko.observableArray([]);
     self.datasourceVehicles = new oj.ArrayTableDataSource(self.vehicles, {idAttribute: "chassisNumber"});
     self.columnsVehicles = ko.observableArray([]);

     self.chartDateStart = ko.observable();
     self.chartDateEnd = ko.observable();

     function getChartDateStart() {
       return new Date(self.currentDate() - 3600 * 24 * 45 * 1000).toISOString();
     }

     function getChartDateEnd() {
       return new Date(self.currentDate() + 3600 * 24 * 2 * 1000).toISOString();
     }

     function getQueryKeys() {
       if(!self.serNum()) { return []; }
       var parts = self.serNum().split(',');
       return parts.map(function(val) {
         return val.trim();
       });
     }

     function queryByKey(key) {
       return new Promise(function (resolve, reject) {
         $.ajax({
           url: `/agent/query/${key}`,
           contentType: 'application/json',
           method: 'POST',
           data: JSON.stringify({config: globalconf})
         }).done(function(resp){
           // console.log(`success: ${resp}`);
           resolve({status: 'success', data: JSON.parse(resp)});
         }).fail(function(jqXHR){
           // console.log(`fail: ${resp}`);
           resolve({status: 'fail', data: jqXHR});
         });
       });
     }

     function setData(resp){
       if(resp.vehicleParts) {
         self.vehicleParts(resp.vehicleParts.map(translateDates));
         var columns = Object.keys(resp.vehicleParts[0]).map(val => {
           return {headerText: val, field: val, sortProperty: val};
         });
         removeDocTypeField(columns);
         self.columnsVehicleParts(columns);
       } else {
         self.vehicleParts([]);
       }
       if(resp.vehicles) {
         self.vehicles(resp.vehicles.map(translateDates));
         var columns = Object.keys(resp.vehicles[0]).map(val => {
           return {headerText: val, field: val, sortProperty: val};
         });
         removeDocTypeField(columns);
         self.columnsVehicles(columns);
       } else {
         self.vehicles([]);
       }
     }

     self.queryVehicleOrParts = function() {
       self.carsMap = {};
       self.carPartsMap = {};
       var promises = [];
       self.currentDate(Date.now());
       self.chartDateStart(getChartDateStart());
       self.chartDateEnd(getChartDateEnd());

       getQueryKeys().forEach(function (key) {
         if(!key || key == '')
          return;
         promises.push(queryByKey(key));
       });
       showQueryLoading('query');
       Promise.all(promises).then(results => {
         var errors = [], cars = [], carParts = [];
         results.forEach(res => {
           // console.log(`status: ${res.status}`);
           if(res.status != 'success') {
             errors.push(JSON.stringify(res.data));
             return;
           }
           if(res.data.length == 0) return;
           //  console.log(res.data[res.data.length-1]);
           var dataLast = res.data[res.data.length-1].Value;
           if(dataLast.hasOwnProperty('serialNumber')) {
             carParts.push(cloneObj(dataLast));
             self.carPartsMap[dataLast['serialNumber']] = res.data;
           } else if (dataLast.hasOwnProperty('chassisNumber')) {
             cars.push(cloneObj(dataLast));
             self.carsMap[dataLast['chassisNumber']] = res.data;
           }
         });

         var resultObj = {};
         if(carParts.length != 0) {
           resultObj['vehicleParts'] = carParts;
         }
         if(cars.length != 0) {
           resultObj['vehicles'] = cars;
         }
         setData(resultObj);

         var obj = {};
         if(carParts.length > 0) obj['VehicleParts'] = self.carPartsMap;
         if(cars.length > 0) obj['Vehicles'] = self.carsMap;
         var text = JSON.stringify(obj, null, 2);
         self.apiDetailInfo(text.replaceAll('\n','<br>').replaceAll(' ','&nbsp;'));

         if(errors.length != 0) {
           console.log(errors.toString());
           alert(`error fetching data - ${errors.toString()}`);
         }
       }).catch(err => {
         console.log(err.toString());
         alert(`Error fetching data - ${err.toString()}`);
       }).then(() => {
         hideQueryLoading('query');
       });
     }

     self.currentDate = ko.observable();
     self.tseries = ko.observableArray();

     self.apiDetailInfo = ko.observable('');
     self.historyDetail = ko.observable('');
     self.tlineSelection = ko.observable([]);
     self.tlineTitle = ko.observable("Vehicle/Part Transfer History");

     function tlineSelectAction(event, data) {
       if (data.option !== 'selection') { return; }
       if (data.optionMetadata.writeback == 'shouldNotWrite') { return; }
       if (!data.value) { return; }
       if (data.value.length == 0) { self.historyDetail(''); return; }
       //  console.log(event);
       //  console.log(data);
       var valparts = data.value[0].split('-');
       var key = valparts[0];
       var txid = valparts[1];
       var chartData = self.chartMap[`chart-${key}`];
       // console.log(chartData);

       var html = `<h4>Transaction ${txid.substring(0,12)} Detail</h4>`;
       var detail = chartData.map[txid];
       //  html += `<b>Timestamp: </b>${dateSecToISO(detail.Timestamp)}<br>`;
       html += `<b>Timestamp: </b>${detail.Timestamp}<br>`;
       var obj = translateDates(cloneObj(detail.Value));
       for(var key in obj) {
         if(key == 'docType') continue;
         html += `<b>${key}: </b>${obj[key]}<br>`;
       }
       chartData.historyDetail(html);
     }

     function getCurrentModel(id) {
       var key, model, map, selection, detail, detailDiv;
       if (id == 'vehicleParts') {
         map = self.carPartsMap;
         key = 'serialNumber';
         model = self.vehicleParts;
         selection = self.carPartSelection;
         detail = self.carPartsDetail;
         detailDiv = 'car-parts-div';
       } else if (id == 'vehicles') {
         map = self.carsMap;
         key = 'chassisNumber';
         model = self.vehicles;
         selection = self.carSelection;
         detail = self.carsDetail;
         detailDiv = 'cars-div'
       }
       return {key: key, model: model, map: map, selection: selection, detail: detail, detailDiv: detailDiv};
     }

     self.carPartSelection = ko.observableArray([]);
     self.carSelection = ko.observableArray([]);

     self.carPartsDetail = ko.observableArray([]);
     self.carPartsDetailDS = new oj.ArrayTableDataSource(self.carPartsDetail, {idAttribute: 'key'});
     self.carsDetail = ko.observableArray([]);
     self.carsDetailDS = new oj.ArrayTableDataSource(self.carsDetail, {idAttribute: 'key'});

     function shortTxId(TxId) {
       return TxId.substring(0, 12);
     }

     self.chartMap = {};
     self.recordSelected = function(event, data) {
       if (data.option !== 'selection') {
         return;
       }
       // console.log(`${event.currentTarget.id}`);
       // console.log(data);
       // console.log(`${event.currentTarget.id} ${data.value?data.value.length:0}`);
       // console.log(JSON.stringify(self.carPartSelection()));
       // console.log(JSON.stringify(self.carSelection()));

       var currentId = event.currentTarget.id;
       var currentModel = getCurrentModel(currentId);

       var details = [];
       var chartMap = {};
       if(currentModel.selection() != null) { // otherwise deselect all in the table
         currentModel.selection().forEach(val => {
           var start = val.startIndex.row;
           var end = val.endIndex.row;
           for(var i = start; i <= end; i++) {
             var key = currentModel.model()[i][currentModel.key];
             var detail = currentModel.map[key];
             //  console.log(detail);

             var detailMap = {};
             detail.forEach(data => {
               detailMap[data.TxId] = data;
             });

             var tseries = detail.map(data => {
               // var date = dateSecToISO(data.Timestamp);
               var date = data.Timestamp;
               var dateObj = date.replace(' +0000 UTC', 'Z').replace(' ', 'T');
               var obj = {"id":`${key}-${data.TxId}`,"title":`TxId: ${shortTxId(data.TxId)}, Owner: ${data.Value.owner}`,"start":dateObj, "description":date};
               return obj;
             });

             var tlineTitle;
             if(detail.length > 0) {
               var data0 = detail[0].Value;
               if(data0.hasOwnProperty('serialNumber')) {
                 tlineTitle = `Transfer History for Vehicle Part ${data0.serialNumber}`;
               } else if (data0.hasOwnProperty('chassisNumber')) {
                 tlineTitle = `Transfer History for Vehicle ${data0.chassisNumber}`;
               }
             }

             var obj = {key: key, detail: detail, map: detailMap, tseries: tseries, tlineTitle: tlineTitle, tlineSelectAction: tlineSelectAction, historyDetail: ko.observable(''), tlineSelection: ko.observableArray([]), closeDetailPane: closeDetailPane};
             details.push(obj);
             self.chartMap[`chart-${key}`] = obj;
           }
         });
       }
       if(details.length > 0) {
         $(`#${currentModel.detailDiv}`).show();
         currentModel.detail(details);
       } else {
         $(`#${currentModel.detailDiv}`).hide();
       }
       // console.log(JSON.stringify(details));
     }

     function closeDetailPane() {
       this.historyDetail('');
       this.tlineSelection([]);
     }

     self.enterPressed = function(event, data) {
       if(event.which != 13) return;
       self.queryVehicleOrParts();
     }

     self.handleActivated = function (info) {
         self.carPartSelection([]);
         self.carSelection([]);
     };
   } // MainViewModel end

   return new MainViewModel();
 });
